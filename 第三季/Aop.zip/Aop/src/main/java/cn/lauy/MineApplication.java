package cn.lauy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Lauy
 * @date 2021/2/2
 */
@SpringBootApplication
public class MineApplication {
    public static void main(String[] args) {
        SpringApplication.run(MineApplication.class,args);
    }
}
