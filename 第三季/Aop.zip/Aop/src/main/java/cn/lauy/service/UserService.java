package cn.lauy.service;

/**
 * @author Lauy
 * @date 2021/2/2
 */
public interface UserService {
    String queryUser(String id);
}
